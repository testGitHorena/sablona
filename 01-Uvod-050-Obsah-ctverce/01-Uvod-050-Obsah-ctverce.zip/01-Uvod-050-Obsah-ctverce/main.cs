using System;

class MainClass {
    public static void Main (string[] args) {
        // Sem přijde váš kód
      int stranaA;
      Console.WriteLine("Zadej hodnotu");
      stranaA = int.Parse(Console.ReadLine());
      int obsah = stranaA*stranaA;
      Console.WriteLine("Obsah ctverce je " + obsah);
    
    
    
        // Konec prostoru pro kód
    }
}