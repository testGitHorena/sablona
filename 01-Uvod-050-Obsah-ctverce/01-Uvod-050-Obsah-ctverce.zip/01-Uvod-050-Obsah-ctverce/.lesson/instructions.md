# Obsah čtverce

Vytvořte algoritmus pro výpočet obsahu čtverce. 

Nejprve poprosíte uživatele o zadání délky strany A. Tu si uložíte do proměnné `stranaA`. 

Pak vypočítáte obsah čtverce a výsledek uživateli vypíšete.