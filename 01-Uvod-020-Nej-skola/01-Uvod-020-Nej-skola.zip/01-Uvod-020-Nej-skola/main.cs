using System;

class MainClass
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Jak se jmenuje tvoje škola?");
        string skola = Console.ReadLine();
        Console.WriteLine(skola + " je nejlepší!");
    }
}