# Nej škola

Tento program by se měl uživatele zeptat na jméno školy a pak říct, že ta je nejlepší.

Z nějakého důvodu ale nechodí. Dokážete jej opravit?