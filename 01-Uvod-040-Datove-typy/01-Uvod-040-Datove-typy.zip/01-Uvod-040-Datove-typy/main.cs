using System;

class MainClass {
    public static void Main (string[] args) {
        int pocetRohliku = 2;
        Console.WriteLine("Kup " + pocetRohliku + " rohlíků");
        
        float cenaZaLitr = 23.5f;
        Console.WriteLine("Za litr nafty dnes zaplatíte " + cenaZaLitr + "Kč");
        
        char prvniPismeno = 'a';
        Console.WriteLine("První písmeno abecedy je \"" + prvniPismeno + "\".");
        
        string textZpravy = "Ahoj svete";
        Console.WriteLine("Přišla mi zpráva s tímto textem: " + textZpravy);
        
        int autaZaDen = 34;
        Console.WriteLine("Dnes naší ulicí projelo " + autaZaDen + " aut.");
        
        char interpunkcniZnamenko = '.';
        Console.WriteLine("K oddělení vět v souvětí používáme symbol \"" + interpunkcniZnamenko + "\"");
        
        float delkaHrany = 3.2f;
        Console.WriteLine("Základna trojúhleníka měří " + delkaHrany + " cm.");
        
        string prijmeni = "Horenovska";
        Console.WriteLine(prijmeni + " je časté příjmení.");
    }
}