# Datové typy

Zvolte vhodné datové typy pro deklarované proměnné a vymyslete si do nich nějakou hodnotu.

