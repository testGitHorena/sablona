# Objem a povrch kvádru

Vytvořte program, kterým 

1. Od uživatele načtete strany kvádru (uživatele hezky vyzvěte). Zadané hodnoty si uložte do dobře pojmenovaných proměnných.
2. Potom z nich vypočítáte objem a povrch kvádru a uložíte je.
3. Vypíšete uživateli v jedné větě výsledky výpočtů.

_Máte to? Zkuste při načítání zařídit, aby výzva a vložení nebyly pod sebou na řádcích, ale na jedno řádku, tedy Počítač napíše:_

`Zadej výšku (v cm):` 

A až uživatel začne psát, bude pokračovat přímo za dvojtečku:

`Zadej výšku (v cm): 43`