# Rozbité dělení

Vyzkoušejte program, přečtete si, co vám píše a objasněte záhadu.

Opravte program tak, aby nelhal.