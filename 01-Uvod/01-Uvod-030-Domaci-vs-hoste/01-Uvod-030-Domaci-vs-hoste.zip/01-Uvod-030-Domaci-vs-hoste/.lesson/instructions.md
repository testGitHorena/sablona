# Domácí vs. hosté

Tento program by se měl uživatele zeptat na góly, které dali domácí a které hosté. Pak by měl vypsat výsledek zápasu.

Z nějakého důvodu ale nechodí. Dokážete jej opravit?

_Pokud si chcete zkusit něco nového, napište poslední řádek bez jediného znaménka +. Nabízí se:_

- Interpolace řetězců: _https://docs.microsoft.com/en-us/dotnet/csharp/tutorials/string-interpolation_
- Formátovací řetězce: _http://zetcode.com/csharp/stringformat/_