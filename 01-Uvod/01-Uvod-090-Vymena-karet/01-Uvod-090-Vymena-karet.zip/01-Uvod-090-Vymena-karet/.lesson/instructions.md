# Výměna karet

V programování se často stává, že potřebujeme vyměnit obsah dvou proměnných - ale jak na to? 

Doplňte program tak. aby si hráči vyměnili karty.
 