using System;

class MainClass {
    public static void Main (string[] args) {
        // Sem přijde váš kód
        
        
        
        // Konec prostoru pro kód
    }
}