# Heronův vzorec (Bonusová úloha)

Vytvořte algoritmus pro výpočet velikosti obsahu trojúhelníka ze tří zadaných stran. 

Taková věc se dělá pomocí Heronova vzorce. Wikipedie napoví.

 