# Pythagorova věta

## Level 1

Vytvořte program pro výpočet délky přepony v pravoúhlém trojúhelníku. Program se (slušně lidsky ;-) ) zeptá na délky obou odvěsen a pak odpoví, jaká je délka přepony.

K vyřešení budete potřebovat zřejmě spočítat druhou odmocninu. Anglicky se řekne square root a víc napoví Google.

## **Level 2**

Udělejte program, který z délky přepony a odvěsny bude buď počítat délku druhé odvěsny, nebo odpoví, že to spočíst nelze (např. při zadání přepony 3 a odvěsny 4). Zjistěte, jak na to…

