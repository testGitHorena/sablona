# Nákupní košík

## Level 1 

Napište program který bude počítat celkový nákup. Začátek máte připraven.

Dopište program dál tak, aby komunikace s ním vypadala takto:

```
PC: Vejce (3,50 Kč): Kolik kusů chcete?
Uživatel: 10

PC: Rohlík (1,90 Kč): Kolik kusů chcete?
Uživatel: 8

PC: Chleba (25 Kč): Kolik kusů chcete?
Uživatel: 1

PC: Celkový nákup bude stát 75,20 Kč.
```

Formátování čísel na dvě desetinná neřešte.

## Level 2

- Změňte program tak, aby se nejprve uživatele zeptal na názvy a ceny zboží, místo toho, aby byly "natvrdo" nastaveny jako v ukázce
- Dořešte formátování na dvě desetinná - v hledání pomůže google, ale nejspíš musíte hledat anglicky.