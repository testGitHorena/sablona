# Obvod a obsah kruhu

Vytvořte program, kterým 

1. Od uživatele načtete poloměr kruhu (uživatele hezky vyzvěte). 
2. Potom z něj vypočítáte obvod a obsah a uložíte je.
3. Vypíšete uživateli v jedné větě výsledky výpočtů.

_Jako číslo π nám nebude stačit_ 3,14_. Zkuste s pomocí Googlu zjistit, jak se v jazyce C# používá číslo π. (Můžete googlit výraz PI, vyhledavač vám bude rozumět)_